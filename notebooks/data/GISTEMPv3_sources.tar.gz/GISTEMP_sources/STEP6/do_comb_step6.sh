#!/bin/ksh

## fortran_compile=$FC
## if [[ $FC = '' ]]
## then echo "set an environment variable FC to the fortran_compile_command like f90"
##   echo "or do all compilation first and comment the compilation lines"
##   exit
## fi

label='GHCN.CL.PA' ; rad=1200

cd ../STEP3/work*/. ; /u/exec/rplmid Ts.ERSST TsERSST  ; cd -
rm -f input_files/*
ln ../STEP3/work*/ANNZON* input_files/.
ln ../STEP3/work*/ZON*0   input_files/.

# std.line.plots Ts ${label}
# std.line.plots.ann Ts ${label}

std.line.plots TsERSST ${label}
std.line.plots.ann TsERSST ${label}
mv *lpl results/.
mv *log work_files
