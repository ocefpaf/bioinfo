#! /usr/bin/python

import string, re, stationstring, bsddb, sys, monthlydata

# keep only stations covering at least 2/3 of the 1951-80 base period

X1 = 1951
X2 = 1980
MIN_YEARS = 2 * (X2 - X1 + 1) / 3.0
BAD = '???'

def main():
    usage = "\n\tusage: bdb_do_cull.py <db_file>"
    assert len(sys.argv) == 2, usage
    db_file = sys.argv[1]
    assert re.search(r'\.bdb$', db_file), usage
    db = bsddb.hashopen(db_file, 'r')
    print "opening %s" % db_file
    new_db_file = re.sub(r'bdb$', 'culled.bdb', db_file)
    print "creating %s" % new_db_file
    new_db = bsddb.hashopen(new_db_file, 'n')
    ids = string.split(db['IDS'])
    new_ids = []

    BAD = string.atoi(db["IBAD"]) / 10.0
    meta_count = 0

    for id in ids:
        s = db[id]
        st = stationstring.new(s)
        dict = st.dict()
        begin = dict['begin']
        data, years = st.data_years()
        end = begin + years - 1
        mon = monthlydata.new(data)
        ann_mean, ann_anoms = mon.annual()
        count = 0
        for year in range(X1, X2 + 1):
            if begin <= year <= end:
                anom = ann_anoms[year - begin]
                if anom != BAD:
                    count = count + 1
        if count >= MIN_YEARS:
            new_db[id] = s
            new_ids.append(id)
            meta_count = meta_count + 1
            if meta_count % 1000 == 0 and meta_count > 0:
                print meta_count
    print meta_count
    new_db['IBAD'] = db['IBAD']
    new_db['IDS'] = string.join(new_ids, ' ')

if __name__ == '__main__':
    main()
