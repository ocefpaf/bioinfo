#! /usr/bin/python

import sys, bsddb, stationstring, re, string

def main():
    if len(sys.argv) != 2 or not re.search(r'\.bdb$', sys.argv[1]):
        print "usage: bdb_to_text.py <bdb_file>"
        sys.exit()
    db_file = sys.argv[1]
    txt_file = re.sub(r'bdb$', 'txt', db_file)
    db = bsddb.hashopen(db_file, 'r')
    print "reading", db_file
    f = open(txt_file, 'w')
    print "creating", txt_file
    ids = string.split(db['IDS'])
    count = 0
    for id in ids:
        count = count + 1
        if count % 1000 == 0:
            print count
        s = db[id]
        st = stationstring.new(s)
        f.write(st.to_text(id))
    print count
    f.close()
    db.close()
    sys.exit()

if __name__ == '__main__':
    main()
