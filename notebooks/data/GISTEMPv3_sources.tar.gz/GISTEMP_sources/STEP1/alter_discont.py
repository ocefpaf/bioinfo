#! /usr/bin/python

import sys, bsddb, string, stationstring

BAD = None
IN_FILE_NAME = "Ts.discont.RS.alter.IN"

def main():
    in_name = sys.argv[1]
    IN_BDB_NAME = in_name + ".bdb"
    OUT_BDB_NAME = in_name + ".alter.bdb"
    in_bdb = bsddb.hashopen(IN_BDB_NAME, "r")
    print "reading", IN_BDB_NAME
    out_bdb = bsddb.hashopen(OUT_BDB_NAME, "c" or "n")
    print "writing", OUT_BDB_NAME

    alter_dict = get_alter_dict()

    global BAD
    BAD = string.atoi(in_bdb["IBAD"]) / 10.0
    BAD = 0.1 * int(BAD * 10.0)
    out_bdb["IBAD"] = in_bdb["IBAD"]

    fill_new_bdb(in_bdb, out_bdb, alter_dict)

def get_alter_dict():
    f = open(IN_FILE_NAME, "r")
    print "reading", IN_FILE_NAME
    dict = {}
    for line in f.readlines():
        id, month, year, num = string.split(line)
        month, year = map(string.atoi, [month, year])
        num = string.atof(num)
        dict[id] = [month, year, num]
    return dict

def fill_new_bdb(in_bdb, out_bdb, alter_dict):
    ids = string.split(in_bdb["IDS"])
    ids_seen = {}
    for id, (a_month, a_year, a_num) in alter_dict.items():
        ids_seen[id] = None
        s = in_bdb[id]
        st = stationstring.new(s)
        dict = st.dict()
        data = st.data()
        years = len(data[0])
        begin = dict["begin"]
        for year in range(begin, a_year + 1):
            index = year - begin
            for m in range(12):
                if year == a_year and m > a_month - 2:
                    continue
                datum = data[m][index]
                if datum == BAD:
                    continue
                if abs(datum - BAD) < 1:
                    print "not BAD: %.20f %.20f %.20f" % (datum, BAD,
                                                       abs(datum - BAD))
                data[m][index] = datum + a_num
        s = stationstring.serialize(dict, data)
        out_bdb[id] = s
    for id in ids:
        if ids_seen.has_key(id):
            continue
        out_bdb[id] = in_bdb[id]
    out_bdb["IDS"] = string.join(ids)
    return

if __name__ == '__main__':
    main()

