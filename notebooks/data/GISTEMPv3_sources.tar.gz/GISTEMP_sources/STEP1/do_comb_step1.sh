#!/bin/ksh

if [[ $# -ne 1 ]] ; then echo "Usage: $0 v3_raw_filename" ; exit ; fi

# the input files are in the directories temp_files and input_files
if [[ ! -s temp_files/$1 ]]
then echo "file temp_files/$1 not found"
     exit ; fi
rm -f $1

if cd temp_files
then for x in *
     do rm -f ../$x ;  ln -s $PWD/$x ../.
     done
     cd ..
fi
if cd input_files
then for x in [Tms]*
     do rm -f ../$x ;  ln -s $PWD/$x ../.
     done
     rm -f ../v3.inv ../ushcn.tbl ; ln -s $PWD/ushcn3.tbl ../ushcn.tbl
                                    ln -s $PWD/v3.inv ../v3.inv
     cd ..
fi

#renames:

echo "Creating $1.bdb" ; v3_to_bdb.py $1
if [[ ! -s $1.bdb ]]   ; then echo "v3_to_bdb.py failed" ; exit ; fi

echo "Dropping strange data "
drop_strange.py $1
    if [[ ! -s $1.strange.bdb ]]
    then echo "drop_strange.py failed" ; exit ; fi

bdb_to_text.py $1.strange.bdb

rm -f $1 ; mkdir work_files 2> /dev/null
mv *bdb work_files/.
mv  ${1}*.txt  temp_files/Ts.txt

echo ; echo "created Ts.txt"
echo "move this file from STEP1/temp_files to STEP2/temp_files "
echo "and execute in the STEP2 directory the command:"
echo "   do_comb_step2.sh last_year_with_data"

# final clean up
if cd temp_files
then for x in *
     do rm -f ../$x
     done
     cd ..
fi
