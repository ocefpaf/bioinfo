The *.py scripts in this directory use the Python programming language. 
Each of these scripts begins with a line indicating the location of
Python on your system. At GISS, this happens to be /usr/bin/python .
You may need to alter this line to specify the location of Python on 
your system, say   /usr/freeware/bin/python or /usr/local/bin/python.

These Python scripts also make use of two custom C extension modules.
These extensions must be compiled and then placed in the site-packages
subdirectory of your computer's Python library. To do so, unarchive the
EXTENSIONS.tar.gz file located here. Then cd into the EXTENSIONS directory.
You will find there the following subdirectories:

  monthlydata
  stationstring

Go into each of these subdirectories and make the C extension: the common
file "Makefile.pre.in" has to be edited to fit your system; the script
"make_shared" does the rest; but it may be safer to do the 3 commands separately.

The resulting *module.so files should end up in the Python site-packages
directory to look something like:
  /usr/lib/python/site-packages/monthlydatamodule.so
  /usr/lib/python/site-packages/stationstringmodule.so
  (assuming your Python library is at /usr/lib/python)
or you may simply move them to the STEP1/. directory.

"make_clean" may be used to remove the files created by "make_shared".
