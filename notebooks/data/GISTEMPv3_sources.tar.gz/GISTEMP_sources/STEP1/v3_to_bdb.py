#! /usr/bin/python

import sys, struct, string, bsddb
import stationstring

BAD = 999.9
IBAD = 9999

def fill_dbm(f, dbm, info, ids, sources):
    line = f.readline()
    ids = []
    while line:
        lines = []
        id = line[:12]
        lines.append(line)
##          print id
        ids.append(id)
        last_id = id
        line = f.readline()
        while line:
            id = line[:12]
            if id != last_id:
                break
            lines.append(line)
            line = f.readline()
        data, begin = stationstring.from_lines(lines)
        st_id = last_id[:-1]
        dict = info[st_id]
        dict['begin'] = begin
        if sources.has_key(last_id):
            dict['source'] = sources[last_id]
        else:
            dict['source'] = 'UNKNOWN'
        mystring = stationstring.serialize(dict, data)
        dbm[last_id] = mystring
    dbm['IDS'] = string.join(ids, ' ')
    dbm['IBAD'] = str(IBAD)
    dbm.close()

def split_title(line):
    template = '11sx30sx6sx7s5s5sc5s2s2s2s2sc2s16sx'
    keys = ('id', 'name', 'lat', 'lon', 'elevs',
            'elevg', 'pop', 'ipop', 'topo', 'stveg',
            'stloc', 'iloc', 'airstn', 'itowndis', 'grveg')
    try:
        tpl = struct.unpack(template, line)
    except struct.error:
        tpl = struct.unpack(template, line[:101])
    ell = len(tpl)
    hash = {}
    for n in range(ell):
        key = keys[n]
        if key == 'id':
            id = tpl[n]
            continue
        value = tpl[n]
        value = string.lstrip(value)
        value = string.rstrip(value)
        hash[key] = value
    return id, hash

def get_sources():
    sources = {}
    fs = {}
    fs['MCDW'] = open('mcdw.tbl', 'r')
    fs['USHCN'] = open('ushcn.tbl', 'r')
    fs['SUMOFDAY'] = open('sumofday.tbl', 'r')
    for source, f in fs.items():
        line = f.readline()
        while line:
            x, id, rec_no = string.split(line)
            id = id + rec_no
            sources[id] = source
            line = f.readline()
        f.close()
    return sources

def get_info():
    f = open('v3.inv', 'r')
    print "reading v3.inv"
    title = f.readline()
    info = {}
    while title:
        id, hash = split_title(title)
        info[id] = hash
        title = f.readline()
    ids = info.keys()
    ids.sort()
    return info, ids

def main():
    infile_name = sys.argv[1]
    bdb_name = infile_name + '.bdb'

    f = open(infile_name, 'r')
    print "reading " + infile_name
    info, ids = get_info()
    sources = get_sources()
    dbm = bsddb.hashopen(bdb_name, 'n')
    print "writing " + bdb_name
    fill_dbm(f, dbm, info, ids, sources)

if __name__ == '__main__':
    main()
