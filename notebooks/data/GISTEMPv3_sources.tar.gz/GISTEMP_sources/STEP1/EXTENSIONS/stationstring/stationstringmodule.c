/*****************************************************************************
 * Copyright (C) 1998, Jay Glascoe, SSAI, NASA/GISS
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *****************************************************************************/

/*****************************************************************************
 * file "stationstringmodule.c", by Jay Glascoe, 1998
 *****************************************************************************/

/* StationString objects */

#include <math.h>
#include <stdio.h>
#include "Python.h"

#define FEQUALS(x, y) (fabs(x - (y)) < 0.1)

static PyObject *StationStringError;

typedef struct {
    PyObject_HEAD
    int length;
    char *dict_sp;
    char *data_sp;
    PyObject *dict;
    PyObject *data;
    long years;
} StationStringObject;

staticforward PyTypeObject StationString_Type;

#define StationStringObject_Check(v) ((v)->ob_type == &StationString_Type)

static StationStringObject *
newStationStringObject(char *sp, int length)
{
    StationStringObject *self;
    char *sp2;
    self = PyObject_NEW(StationStringObject, &StationString_Type);
    if (self == NULL)
	return NULL;

    self->dict_sp = (char *)PyMem_Malloc((length + 1) * sizeof(char));
    if (self->dict_sp == NULL)
	return NULL;
    
    strcpy(self->dict_sp, sp);
    
    for (sp2 = self->dict_sp; *sp2 != '\n'; ++sp2)
	/* nada */;
    
    *sp2 = '\0';
    self->data_sp = ++sp2;
    self->dict = NULL;
    self->data = NULL;
    self->years = 0;

/*      printf("string: '%s'\ndict: '%s'\ndata: '%s'\nlength: %d\n", */
/*  	   sp, self->dict_sp, self->data_sp, length); */

    return self;
}

/* StationString methods */

static PyObject *
StationString_dict(StationStringObject *self, PyObject *args)
{
    char *sp = self->dict_sp;
    char *kp;
    char *vp;
    PyObject *pydict;
    if (!PyArg_ParseTuple(args, ""))
	return NULL;
    if (self->dict != NULL)
    {
	Py_INCREF(self->dict);
	return self->dict;
    }
    pydict = PyDict_New();
    if (pydict == NULL)
	return NULL;
    for (kp = strtok(sp, "\t"), vp = strtok(NULL, "\t");
	 vp != NULL;
	 kp = strtok(NULL, "\t"), vp = strtok(NULL, "\t"))
    {
	PyObject *pyval;
	if (strcmp(kp, "begin") == 0 || strcmp(kp, "ipop") == 0)
	    pyval = PyInt_FromLong((long)atoi(vp));
	else if (strcmp(kp, "lat") == 0 || strcmp(kp, "lon") == 0)
	    pyval = PyFloat_FromDouble((double)atof(vp));
	else
	    pyval = PyString_FromString(vp);
	PyDict_SetItemString(pydict, kp, pyval);
	Py_DECREF(pyval);
    }
    self->dict = pydict;
    Py_INCREF(pydict);
    return pydict;
}

static PyObject *
StationString_years(StationStringObject *self, PyObject *args)
{
    char *sp = self->data_sp;
    char *dp;
    long length;
    if (self->years != 0)
	return PyInt_FromLong(self->years);
    for (length = 1, dp = sp; *dp != 0; ++dp, *dp == ' ' ? ++length : 0)
	/* nada */ ;
    self->years = length / 12;
    return PyInt_FromLong(self->years);
}

static PyObject *
StationString_data_years(StationStringObject *self, PyObject *args)
{
    char *sp = self->data_sp;
    char *dp;
    int m;
    PyObject *pydata;
    PyObject *pyyears;
    PyObject *ret;
    if (self->data != NULL)
    {
	if (self->years == 0)
	    return NULL;
	ret = Py_BuildValue("Ol", self->data, self->years);
	return ret;
    }
    pydata = PyList_New(12);
    if (pydata == NULL)
	return NULL;
    if (self->years == 0)
    {
	pyyears = StationString_years(self, args);
	Py_DECREF(pyyears);
    }
    dp = (char *)PyMem_Malloc(20 * sizeof(char));
    for (m = 0, dp = strtok(sp, " "); m < 12; ++m)
    {
	int n;
	PyObject *monthly = PyList_New(self->years);
	if (monthly == NULL)
	    return NULL;
	for (n = 0; n < self->years; ++n, dp = strtok(NULL, " "))
	{
	    double datum = atoi(dp) * 0.1;
	    PyList_SetItem(monthly, n, PyFloat_FromDouble(datum));
	}
	PyList_SetItem(pydata, m, monthly);
    }
    self->data = pydata;
    return Py_BuildValue("Ol", pydata, self->years);
}

static PyObject *
StationString_data(StationStringObject *self, PyObject *args)
{
    PyObject *tuple;
    PyObject *retval;
    if (self->data != NULL)
    {
	Py_INCREF(self->data);
	return self->data;
    }
    tuple = StationString_data_years(self, args);
    retval = PyTuple_GetItem(tuple, 0);
    Py_INCREF(retval);
    Py_DECREF(tuple);
    return retval;
}

static void
StationString_dealloc(StationStringObject *self)
{
    PyMem_Free(self->dict_sp);
    /* PyMem_Free(self->data_sp); */
    Py_XDECREF(self->dict);
    Py_XDECREF(self->data);
    /* PyMem_DEL(self); */
}

static PyObject *
StationString_to_text(StationStringObject *self, PyObject *args)
{
    int maxlen = 8192;
    char *text = PyMem_Malloc(maxlen * sizeof(char));
    char *id;
    PyObject *py_empty_tuple = PyTuple_New(0);
    PyObject *pydict = StationString_dict(self, py_empty_tuple);
    PyObject *pydata = StationString_data(self, py_empty_tuple);
    PyObject *pytext;
    int offset = 0;
    int begin = (int)PyInt_AsLong(PyDict_GetItemString(pydict, "begin"));
    Py_DECREF(py_empty_tuple);
    if (!PyArg_ParseTuple(args, "s", &id))
	return NULL;
    {
	char format[] = " %4ld%5ld%s%4s%-36s";
	double lat = PyFloat_AsDouble(PyDict_GetItemString(pydict, "lat"));
	double lon = PyFloat_AsDouble(PyDict_GetItemString(pydict, "lon"));
	char *ht = PyString_AsString(PyDict_GetItemString(pydict, "elevs"));
	char *name =PyString_AsString(PyDict_GetItemString(pydict, "name"));
	long ilat = (long)floor(10.0 * lat + 0.5);
	long ilon = (long)floor(10.0 * lon + 0.5);
	offset += sprintf(text, format, ilat, ilon, id, ht, name);
	text[offset] = '\n';
	++offset;
    }
    {
	int n;
	for (n = 0; n < self->years; ++n)
	{
	    int year = n + begin;
	    int m;
	    offset += sprintf(text + offset, "%4d", year);
	    for (m = 0; m < 12; ++m)
	    {
		PyObject *pyrow = PyList_GetItem(pydata, m);
		double datum = PyFloat_AsDouble(PyList_GetItem(pyrow, n));
		long idatum = (long)floor(datum * 10.0 + 0.5);
		offset += sprintf(text + offset, "%5ld", idatum);
	    }
	    text[offset] = '\n';
	    ++offset;
	    if (offset > maxlen / 2)
	    {
		maxlen *= 2;
		text = (char *)PyMem_Realloc(text, maxlen * sizeof(char));
	    }
	}
	text[offset] = 0;
    }
    pytext = PyString_FromStringAndSize(text, offset);
    Py_DECREF(pydict);
    Py_DECREF(pydata);
    PyMem_Free((void *)text);
    return pytext;
}

static PyObject *
StationString_combine(StationStringObject *self, PyObject *args)
{
    PyObject *pydict = NULL;
    PyObject *pyothers;

    long new_years, new_begin, new_end, length;
    double BAD;

    int j, i, n, m;
    int me_pos  ; /* Py_ssize_t me_pos; */
    PyObject *me_key, *me_value;

    double *new_sums[12];
    long *new_wgts[12];
    
    PyObject *pynew_data;
    PyObject *pynew_dict;
    PyObject *retval;
    PyObject *empty_args = PyTuple_New(0);
    
    if (!PyArg_ParseTuple(args, "Od", &pyothers, &BAD))
	return NULL;

    new_begin = 9999;
    new_end = -9999;

    PyList_Append(pyothers, (PyObject *)self);

    length = PyList_Size(pyothers);
    for (n = 0; n < length; ++n)
    {
	StationStringObject *other = \
	    (StationStringObject *)PyList_GetItem(pyothers, n);
        PyObject *other_pydict = StationString_dict(other, empty_args);
	PyObject *other_pydata = StationString_data(other, empty_args);
	long other_years = other->years;
	long other_begin = \
	    PyInt_AsLong(PyDict_GetItemString(other_pydict, "begin"));
	long other_end = other_begin + other_years - 1;
	if (other_begin < new_begin)
	    new_begin = other_begin;
	if (other_end > new_end)
	    new_end = other_end;
	Py_DECREF(other_pydict);
	Py_DECREF(other_pydata);
/*  	printf("okay1\n"); */
	fflush(stdout);
    }
    new_years = new_end - new_begin + 1;

/*  	printf("okay2 %d %d %d\n", new_years, new_begin, new_end); */
    for (m = 0; m < 12; ++m)
    {
	int n;
	
	new_sums[m] = (double *)PyMem_Malloc(new_years * sizeof(double));
	new_wgts[m] = (long *)PyMem_Malloc(new_years * sizeof(long));
	
	for (n = 0; n < new_years; ++n)
	    new_sums[m][n] = new_wgts[m][n] = 0;
    }
    	
    for (i = 0; i < length; ++i)
    {
	StationStringObject *other = \
	    (StationStringObject *)PyList_GetItem(pyothers, i);
        PyObject *other_pydict = other->dict;
	PyObject *other_pydata = other->data;
	long other_years = other->years;
	long other_begin = \
	    PyInt_AsLong(PyDict_GetItemString(other_pydict, "begin"));
	int m;
	for (m = 0; m < 12; ++m)
	{
	    PyObject *other_monthly = PyList_GetItem(other_pydata, m);
	    int n;
	    for (n = 0; n < other_years; ++n)
	    {
		long year;
		double datum = \
		    PyFloat_AsDouble(PyList_GetItem(other_monthly, n));
/*  		printf("okay3 %f\n", datum); */
		fflush(stdout);
		if (FEQUALS(datum, BAD))
		    continue;
		year = n + other_begin;
		new_sums[m][year - new_begin] += datum;
		new_wgts[m][year - new_begin] += 1;
	    }
	}
    }

    pynew_data = PyList_New(12);
    
    for (m = 0; m < 12; ++m)
    {
	PyObject *pynew_monthly = PyList_New(new_years);
	for (n = 0; n < new_years; ++n)
	{
	    long wgt = new_wgts[m][n];
	    double new_datum;
	    if (wgt == 0)
		new_datum = BAD;
	    else
		new_datum = new_sums[m][n] / wgt;
	    PyList_SetItem(pynew_monthly, n, PyFloat_FromDouble(new_datum));
	}
	PyList_SetItem(pynew_data, m, pynew_monthly);
    }
    
    pynew_dict = PyDict_New();
    me_pos = 0;
    pydict = self->dict;
    
    while ( (j = PyDict_Next(pydict, &me_pos, &me_key, &me_value)) )
    {
	Py_INCREF(me_key);
	Py_INCREF(me_value);
	PyDict_SetItem(pynew_dict, me_key, me_value);
    }
    PyDict_SetItemString(pynew_dict, "begin", PyInt_FromLong(new_begin));

    for (m = 0; m < 12; ++m)
    {
	PyMem_Free((void *)new_sums[m]);
	PyMem_Free((void *)new_wgts[m]);
    }
    	
    retval = PyTuple_New(3);
    PyTuple_SetItem(retval, 0, pynew_dict);
    PyTuple_SetItem(retval, 1, pynew_data);
    PyTuple_SetItem(retval, 2, PyInt_FromLong(new_years));
/*      Py_DECREF(pynew_dict); */
/*      Py_DECREF(pynew_data); */

    return retval;
}

static PyMethodDef StationString_methods[] = {
	{"dict",	(PyCFunction)StationString_dict,	1},
	{"data_years",	(PyCFunction)StationString_data_years,	1},
	{"data",	(PyCFunction)StationString_data,	1},
	{"years",	(PyCFunction)StationString_years,	1},
	{"to_text",	(PyCFunction)StationString_to_text,	1},
	{"combine",	(PyCFunction)StationString_combine,	1}, 
	{NULL,		NULL}		/* sentinel */
};

static PyObject *
StationString_getattr(StationStringObject *self, char *name)
{
    return Py_FindMethod(StationString_methods, (PyObject *)self, name);
}

static PyTypeObject StationString_Type = {
	PyObject_HEAD_INIT(&PyType_Type)
	0,			/*ob_size*/
	"StationString",			/*tp_name*/
	sizeof(StationStringObject),	/*tp_basicsize*/
	0,			/*tp_itemsize*/
	/* methods */
	(destructor)StationString_dealloc, /*tp_dealloc*/
	0,			/*tp_print*/
	(getattrfunc)StationString_getattr,           /*tp_getattr*/
	0,                      /*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
	0,			/*tp_hash*/
};
/* --------------------------------------------------------------------- */
/* List of functions defined in the module */

static PyObject *
stationstring_new(PyObject *self, PyObject *args)      
{
    StationStringObject *rv;
    PyObject *pysp;
    char *sp;
    int length;
    if (!PyArg_ParseTuple(args, "O", &pysp))
	return NULL;

    sp = PyString_AsString(pysp);
    length = PyString_Size(pysp);

    rv = newStationStringObject(sp, length);

    if ( rv == NULL )             
	return NULL;
/*      printf("okay rv != NULL\n"); */
    
    return (PyObject *)rv;
}

static PyObject *
stationstring_serialize(PyObject *self, PyObject *args)
{
    PyObject *pydict;
    PyObject *pydata;
    PyObject *pystring;
    int len = 0;
    int maxlen = 8192;

    char *string = (char *)PyMem_Malloc(maxlen * sizeof(char));
    
    PyObject *pkey;
    PyObject *pvalue;
    int m;
    int j ; /* Py_ssize_t j; */
    int ppos; /* Py_ssize_t ppos; */
    if (!PyArg_ParseTuple(args, "OO", &pydict, &pydata))
	return NULL;

    ppos = 0;
    while ( (j = PyDict_Next(pydict, &ppos, &pkey, &pvalue)) )
    {
	int key_len = PyString_Size(pkey);
	char *key_string = PyString_AsString(pkey);
	char *value_string;
	int value_len;
	
	fflush(stdout);

	strcpy(string + len, key_string);
	len += key_len;
	string[len] = '\t';
	++len;

	if (PyString_Check(pvalue))
	{
	    value_string = PyString_AsString(pvalue);
	    value_len = PyString_Size(pvalue);
	}
	else
	{
	    PyObject *str_value = PyObject_Str(pvalue);
	    value_string = PyString_AsString(str_value);
	    value_len = PyString_Size(str_value);
	    Py_DECREF(str_value);
	}

	strcpy(string + len, value_string);
	len += value_len;

	string[len] = '\t';
	++len;
	/* PyMem_Free(key_string); */
	/* PyMem_Free(value_string); */
	if (len > maxlen / 2)
	{
	    maxlen *= 2;
	    string = (char *)PyMem_Realloc(string, maxlen * sizeof(char));
	}
    }
    PyDict_Next(pydict, &j, &pkey, &pvalue);
    
    string[len - 1] = '\n';
    
    for (m = 0; m < 12; ++m)
    {
	
	PyObject *monthly = PyList_GetItem(pydata, m);
	int years = PyList_Size(monthly);
	int n;
	for (n = 0; n < years; ++n)
	{
	    PyObject *pydatum = PyList_GetItem(monthly, n);
	    double datum = PyFloat_AsDouble(pydatum);
	    len += sprintf(string + len, "%d ", (int)floor(datum*10.0 + 0.5));
	    if (len > maxlen / 2)
	    {
		maxlen *= 2;
		string = (char *)PyMem_Realloc(string, maxlen * sizeof(char));
	    }
	}
    }
    string[len - 1] = '\0';
    
    pystring = PyString_FromString(string);
    PyMem_Free(string);
    
    return pystring;
}

static PyObject *
stationstring_from_lines(PyObject *self, PyObject *args)
{
    long begin, end, size, years, IBAD = 9999L;
    PyObject *pylines, *pydata, *retval;
    int i;
    
    if (!PyArg_ParseTuple(args, "O", &pylines))
	return NULL;

    begin = 9999;
    end = 0;

    size = PyList_Size(pylines);
    for (i = 0; i < size; ++i) 
    {
	PyObject *pyline = PyList_GetItem(pylines, i);
	char *line = PyString_AsString(pyline);
	char id[20];
	int year;
	if (!sscanf(line, "%12s%4d", id, &year))
	    return NULL;
	if (year < begin)
	    begin = year;
	if (year > end)
	    end = year;
    }
    years = end - begin + 1;
    {
	long **data = (long **)PyMem_Malloc(years * sizeof(long *));
	int m, n;
	pydata = PyList_New(12);
	for (n = 0; n < years; ++n)
	{
	    data[n] = (long *)PyMem_Malloc(12 * sizeof(long));
	    for (m = 0; m < 12; ++m)
		data[n][m] = IBAD;
	}
	for (i = 0; i < size; ++i)
	{
	    PyObject *pyline = PyList_GetItem(pylines, i);
	    char *line = PyString_AsString(pyline);
	    int index, offset, year;
	    if (!sscanf(line + 12, "%4d", &year))
		return NULL;
	    index = year - begin;
	    for (m = 0, offset = 16; m < 12; ++m, offset += 5)
	    {
		long idatum;
		if (!sscanf(line + offset, "%5ld", &idatum))
		{
		    printf("'%s' %d '%s'\n", line, offset, line + offset);
		    return NULL;
		}
		if (idatum == -9999)
		    idatum = IBAD;
		data[index][m] = idatum;
	    }
	}
	for (m = 0; m < 12; ++m)
	{
	    PyObject *pymonthly = PyList_New(years);
	    for (n = 0; n < years; ++n)
		PyList_SetItem(pymonthly, n,
			       PyFloat_FromDouble((double)(data[n][m]) * 0.1));
	    PyList_SetItem(pydata, m, pymonthly);
	}

	/* cleanup */
	for (n = 0; n < years; ++n)
	    PyMem_Free((void *)data[n]);
	PyMem_Free((void *)data);
    }
    retval = Py_BuildValue("Ol", pydata, begin);
    Py_DECREF(pydata);
    return retval;
}

static PyMethodDef stationstring_methods[] = {
	{"new",                 stationstring_new,		1},
	{"serialize",		stationstring_serialize,		1},
	{"from_lines",          stationstring_from_lines,       1},
	{NULL,		NULL}		/* sentinel */
};


/* Initialization function for the module (*must* be called initxx) */

void
initstationstring()
{
    PyObject *m, *d;
    /* Create the module and add the functions */
    m = Py_InitModule("stationstring", stationstring_methods);

    /* Add some symbolic constants to the module */
    d = PyModule_GetDict(m);
    StationStringError = PyErr_NewException("stationstring.error", NULL, NULL);
    if (StationStringError != NULL)
	PyDict_SetItemString(d, "error", StationStringError);
}
