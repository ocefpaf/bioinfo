#!/bin/ksh

fortran_compile=$FC
if [[ $FC = '' ]]
then echo "set an environment variable FC to the fortran_compile_command like f90"
     echo "or do all compilation first and comment the compilation lines"
     exit
fi

label='GHCN.CL.PA' ; rad=1200
if [[ $# -gt 0 ]] ; then rad=$1 ; fi

i="temp_files/Ts.${label}"

if [[ ! -s $i.1 ]] ; then echo "input files ${i}.1-6 missing"; exit; fi

##  Input files:
n=1
while [[ $n -le 6 ]]
do
   ln ${i}.$n  fort.3$n
   (( n=$n + 1 ))
done

${fortran_compile} to.SBBXgrid.f -o to.exe
to.exe 1880 $rad > to.SBBXgrid.1880.$label.$rad.log

##   Output files:

echo "The following files were created:"
echo "SBBX1880.Ts.${label}.$rad    BX.Ts.${label}.$rad  "
mv fort.10 SBBX1880.Ts.${label}.$rad
mv fort.11   BX.Ts.${label}.$rad
mv fort.77   statn.use.Ts.${label}.$rad

if [[ $rad -eq 1200 ]] ; then ./zonav $label ; fi

./trimSBBX SBBX1880.Ts.${label}.$rad

# Clean-up
rm fort.3[0-6] ; rm  to.exe
mv *exe *log *use* work_files/.
a=$( ls SBBX*.trim ) ; mv $a temp_files/${a%.trim}
mv BX* SBBX* work_files/.

echo ; echo "If you don't want to use ocean data, you may stop at this point"
echo "You may use the utilities provided on our web site to create maps etc"
echo "using temp_files/SBBX1880.Ts.${label}.$rad as input file" ; echo

echo "In order to combine this with ocean data, proceed as follows:"
echo "move SBBX1880.Ts.${label}.$rad from STEP3/temp_files to STEP4_5/input_files/."
echo "create/update the SST-file SBBX.HadR2 and move it to STEP4_5/input_files/."
echo "You may use do_comb_step4.sh to update an existing SBBX.HadR2 file"
echo "You may use do_comb_step5.sh to create the temperature anomaly tables"
echo "that are based on land and ocean data"
