The following files have to be downloaded and added to the input_files/. directory :

ghcnm.tavg.latest.qca.tar.gz (from GHCN v3) - type: "gunzip *gz" and    "tar -xpf *.tar"
                                              then:   ln ghcnm.v3.1.0.*/*.dat adj_data

antarc1.txt, antarc3.txt     (from SCAR, manual updates)
antarc2.txt                  (from SCAR if any changes occurred - not likely !)
                   see also: input_files/preliminary_manual_steps.txt

To simplify comparisons to older antarc*txt files, you may execute the "do_sort"
script; this will create duplicates of these files in which the stations are ordered
alphabetically called antarc*.sort.txt - all while in the input_files/. directory .

An environment variable FC has to be set to a fortran90 compilation command, e.g.
        f90 , ifort , "xlf90 -qfixed" , gfortran , ...

Then the command "do_comb_step0.sh" should do the rest and put the file
v3.mean_comb into the temp_files/. directory . All auxiliary and log files are
collected in the work_files/. directory .

The next steps would be: 
      mv temp_files ../STEP1/. ; cd ../STEP1 ; do_comb_step1.sh v3.mean_comb
