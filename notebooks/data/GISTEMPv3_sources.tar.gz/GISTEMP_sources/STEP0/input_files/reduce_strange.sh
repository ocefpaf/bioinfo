#! /bin/ksh

while read a b
do if [[ $a != '425'* ]]
   then echo "$a $b"
   else c=$( grep $a ../USHCN.v2.mean_noFIL | head -1 ) 2> /dev/null
      if [[ $c != '' ]]
      then echo "$a $b"
      fi
   fi
done < Ts.strange.RSU.list.IN_full > Ts.strange.RSU.list.IN
