if [[ $# -ne 2 ]]
then echo $0 combines arg1=antarctic data with arg2=v2.mean ; exit ; fi
fortran_compile=$FC
ln $1 fort.1
ln $2 fort.2
${fortran_compile} antarc_comb.f -o antarc_comb.exe
antarc_comb.exe ; rm -f antarc_comb.exe
mv fort.12 v2.meanx
rm -f fort.[12]
echo "created v2.meanx from v2_antarct.dat and v2.mean"
