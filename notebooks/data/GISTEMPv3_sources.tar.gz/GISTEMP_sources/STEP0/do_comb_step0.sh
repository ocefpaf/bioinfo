#!/bin/ksh
infile=input_files/v3.mean  ; # will be created from adj_data by v3_to_v2.exe

mkdir temp_files   2> /dev/null
mkdir work_files   2> /dev/null

export FC="/opt/pware/bin/gfortran -fconvert=big-endian -frecord-marker=4"
fortran_compile=$FC
if [[ $FC = '' ]]
then echo "set an environment variable FC to the fortran_compile_command like f90"
     echo "or do all compilation first and comment the compilation lines"
     exit
fi

echo "reformatting to v2 format"
${FC} v3_to_v2.f -o v3_to_v2.exe ; cd input_files ; ../v3_to_v2.exe
cd ..
if [[ ! -s $infile ]] ; then echo "$infile not found" ; exit ; fi

echo "Bringing Antarctic tables closer to v2.mean format"
./antarc_to_v2.sh $1

echo "adding extra Antarctica station data to ${infile}"
${fortran_compile} antarc_comb.f -o antarc_comb.exe
antarc_comb.exe v2_antarct.dat ${infile}
echo "created v2.meanx from v2_antarct.dat and ${infile}"
rm -f v2_antarct.dat antarc_comb.exe

# echo "removing pre-1880 data:"
echo ; echo "GHCN data:"
${fortran_compile} dump_old.f -o dump_old.exe
dump_old.exe v2.meanx v2.meanz 1880 ; echo "created v2.meanz from v2.meanx"
rm -f v2.meanx

cp input_files/Ts.strange.v3.list.IN_full temp_files/Ts.strange.RSU.list.IN

echo "replacing Hohenspeissenberg data in v3.mean by more complete data (priv.comm.)"
echo "disregard pre-1880 data:"
tail +100 input_files/t_hohenpeissenberg_200306.txt_as_received_July17_2003 > t_hohenpeissenberg
${fortran_compile} hohp_to_v2.f -o hohp_to_v2.exe
${fortran_compile} cmb.hohenp.v2.f -o cmb.hohenp.v2.exe
hohp_to_v2.exe ;  cmb.hohenp.v2.exe

# cleanup
mv    v2.mean temp_files/v3.mean_comb
mv -f *.exe v2.mean* ghcn* ushcn* hcn*  *hohenpeiss* work_files/. 2> /dev/null

echo ; echo "created v3.mean_comb"
echo "move files from temp_files/. to ../STEP1/temp_files/. "
echo "and execute in the STEP1 directory the command:"
echo "   do_comb_step1.sh v3.mean_comb"
