#!/bin/ksh

if [[ $# -lt 1 ]]
then echo "Usage: $0 last_year_with_data urbadj_flag (0: popul, 1:Glb-NightLights)"
     exit ; fi

fortran_compile=$FC
if [[ $FC = '' ]]
then echo "set an environment variable FC to the fortran_compile_command like f90"
     echo "or do all compilation first and comment the compilation lines"
     exit
fi

infile=temp_files/Ts.txt ; label='GHCN.CL' ; last_year=$1 ; ua_flag=${2:-1}
if [[ ! -s $infile ]]
then echo "$infile not found - get it from the previous step - no action"
   exit ; fi

echo "converting text to binary file"
  ln -s input_files/v3.inv  v3.inv
  rm -f Ts.txt ; ln -s $infile Ts.txt
  ${fortran_compile} text_to_binary.f -o text_to_binary.exe ; text_to_binary.exe $last_year $ua_flag

echo "breaking up Ts.bin into 6 zonal files"
  ${fortran_compile} split_binary.f -o split_binary.exe ; split_binary.exe

echo "trimming Ts.bin1-6"
  ${fortran_compile} trim_binary.f -o trim_binary.exe ; trim_binary.exe

for i in 1 2 3 4 5 6
do  mv Ts.bin${i}.trim Ts.${label}.$i
done

rm -f Ts.bin Ts.txt

echo "preparations for urban adjustment"
  ${fortran_compile} invnt.f -o invnt.exe ; ./invnt.exe Ts.${label} > Ts.${label}.station.list

echo "Creating annual anomalies ANN.d$1.[1-6]"
./toANNanom Ts.${label}

${fortran_compile} PApars.f tr2.f t2fit.f -o PApars.exe
${fortran_compile}  flags.f               -o  flags.exe
${fortran_compile} padjust.f              -o padjust.exe

./PApars ${label}
./padjust Ts.${label}

./invnt.exe Ts.${label}.PA > Ts.${label}.PA.station.list

mkdir work_files 2> /dev/null
mv ANN* Ts*bin* *exe *log* *use*  work_files/.
mv Ts* temp_files/.    ; mv *list work_files/.
rm -f v3.inv

echo ; echo "created Ts.${label}.* files"
echo "move them from STEP2/temp_files to STEP3/temp_files"
echo "and execute in STEP3 do_comb_step3.sh "
