if [[ $# -lt 2 ]]
then echo "Usage: $0 year month1 month2";
     echo "       to add some months to SBBX.ERSST"
     exit; fi

fortran_compile=$FC
if [[ $FC = '' ]]
then echo "set an environment variable FC to the fortran_compile_command like f90"
     echo "or do all compilation first and comment the compilation lines"
     exit
fi

if [[ ! -s input_files/SBBX.ERSST ]]
then echo "file input_files/SBBX.ERSST not found" ; exit ; fi

mo=$2 ; if [[ mo -lt 10 ]] ; then mo='0'${mo} ; fi
if [[ ! -s input_files/oiv2mon.$1$mo ]]
then echo "file input_files/oiv2mon.$1$mo not found" ; exit ; fi

mo2=$2 ; if [[ $# -gt 2 ]]; then mo2=$3 ; fi

$FC convert1.ERSST_mod4.f -o convert1.ERSST_mod4.exe
convert1.ERSST_mod4.exe $1 $2 $mo2
trimSBBX SBBX.ERSST.upd

echo 'If all went ok, type "mv SBBX.ERSST.upd.trim input_files/SBBX.ERSST"'
echo '          then  type: do_comb_step5.sh 100 0'
