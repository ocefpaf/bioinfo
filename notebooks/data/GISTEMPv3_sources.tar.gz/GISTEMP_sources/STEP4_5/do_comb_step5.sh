#!/bin/ksh

fortran_compile=$FC
 if [[ $FC = '' ]]
 then echo "set an environment variable FC to the fortran_compile_command like f90"
   echo "or do all compilation first and comment the compilation lines"
   exit
fi

RLand=100 ; # up to 100km from a station, land surface data have priority over ocean data
if [[ $# -gt 0 ]] ; then RLand=$1 ; fi

i1="input_files/SBBX1880.Ts.GHCN.CL.PA.1200"
i2="input_files/SBBX.ERSST"

if [[ ! -s $i1 ]] then echo "input file $i1 missing"; exit; fi
if [[ ! -s $i2 ]] then echo "input file $i2 missing"; exit; fi
echo  'inputfiles: ' $i1 $i2

## mv $0.log out/.  2> /dev/null ;   mv BX.${1}x ../old/.  2> /dev/null
##  Input files:
ln -s $i1 fort.10
ln -s $i2 fort.11

$FC  SBBXotoBX.f -o to.exe
to.exe $RLand 0 > SBBXotoBX.log

##   Output files:

echo "The following file was created:"
echo "BX.Ts.ERSST.GHCN.CL.PA.1200"
mv fort.12   BX.Ts.ERSST.GHCN.CL.PA.1200

# Clean-up
rm fort.1[01] ; ## rm to.exe

mkdir work_files 2> /dev/null
zonav  ERSST.GHCN.CL.PA
mv BX* work_files/.
cd work_files
../rplmid Ts.ERSST TsERSST
cd ../results
../rplmid Ts.ERSST TsERSST   ; mv * ../../STEP3/results/.
cd .. ; mv *log work_files/.
